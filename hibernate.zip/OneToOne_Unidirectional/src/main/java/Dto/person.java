package Dto;

public class person {

}
