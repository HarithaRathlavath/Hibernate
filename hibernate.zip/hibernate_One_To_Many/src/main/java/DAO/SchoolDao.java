package DAO;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import DTO.School;
import DTO.Students;

public class SchoolDao {
	EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("vivek");
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	EntityTransaction entityTransaction = entityManager.getTransaction();

	public void insertDetails(School school) {
		List<Students>list=school.getStudents();
		entityTransaction.begin();
		for(Students students:list)
		entityManager.persist(students);
		entityManager.persist(school);
		entityTransaction.commit();

	}
	public void fetchAll() 
	{
		Query query=entityManager.createQuery("select t from School t");
		@SuppressWarnings("unchecked")
		List<School>list=query.getResultList();
		Iterator<School> iterator=list.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
	public void fetchId(int id) {
		School school=entityManager.find(School.class, id);
		if(school!=null) {
			System.out.println(school);
		}
	}
	public void updateAll() {
		
	}
}
