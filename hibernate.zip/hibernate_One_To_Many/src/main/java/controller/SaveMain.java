package controller;

import java.util.ArrayList;
import java.util.List;

import DAO.SchoolDao;
import DTO.School;
import DTO.Students;

public class SaveMain {

	public static void main(String[] args) {
		School school = new School();
		school.setSchoolName("vvhs");
		school.setSchoolFee(10000);
		school.setSchoolAddress("nzb");

		Students students = new Students();
		students.setStudentName("pappu");
		students.setStudentAge(12);
		students.setStudentDOB("2014");
		students.setStudentAddress("nzb");
		Students students1 = new Students();
		students1.setStudentName("rohti");
		students1.setStudentAge(11);
		students1.setStudentDOB("2015");
		students1.setStudentAddress("nzb");
		Students students2 = new Students();
		students2.setStudentName("anand");
		students2.setStudentAge(13);
		students2.setStudentDOB("2013");
		students2.setStudentAddress("nzb");
		Students students3 = new Students();
		students3.setStudentName("vivek");
		students3.setStudentAge(12);
		students3.setStudentDOB("2014");
		students3.setStudentAddress("nzb");
		
		
		
		List<Students>list=new ArrayList<Students>();
		list.add(students);
		list.add(students1);
		list.add(students2);
		list.add(students3);
		
		school.setStudents(list);
		new SchoolDao().insertDetails(school);
	}

}
