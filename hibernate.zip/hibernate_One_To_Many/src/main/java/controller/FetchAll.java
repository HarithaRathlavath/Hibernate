package controller;

import DAO.SchoolDao;

public class FetchAll {

	public static void main(String[] args) {
		
		new SchoolDao().fetchAll();
		new SchoolDao().fetchId(1);
	}

}
