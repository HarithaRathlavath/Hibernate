package Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import Dto.CustomerDto;
import Dto.Product;

public class MainClass {

	
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("magician");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		
		public void insert(CustomerDto customerDto)
		{
		
			List<Product> products=customerDto.getProducts();
			et.begin();
			for (Product product : products) 
			{
				em.persist(product);
			}
			em.persist(customerDto);
			et.commit();
		}
		public CustomerDto fetch(int id)
		{
			Query query=em.createQuery("select c from customer c where c.cid=?1");
			query.setParameter(1, query);
			CustomerDto customerDto=em.find(CustomerDto.class, query);
			
			return customerDto;
		}
		
	

}
