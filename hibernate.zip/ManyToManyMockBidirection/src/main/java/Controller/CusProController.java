package Controller;

import Dto.CustomerDto;

import Dto.Product;
import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import Dao.MainClass;

public class CusProController {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("magician");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		CustomerDto c1 = new CustomerDto();
		CustomerDto c2 = new CustomerDto();
		CustomerDto c3 = new CustomerDto();

		System.out.println("enter the customer name ");
		String name = sc.next();
		c1.setCname(name);
		System.out.println("enter the customer address ");
		String add = sc.next();
		c1.setAddress(add);
		System.out.println("enter the customer phone number ");
		long phno = sc.nextLong();
		c1.setPhno(phno);

		System.out.println("enter the customer name ");
		String name1 = sc.next();
		c2.setCname(name1);
		System.out.println("enter the customer address ");
		String add1 = sc.next();
		c2.setAddress(add1);
		System.out.println("enter the customer phone number ");
		long phno1 = sc.nextLong();
		c2.setPhno(phno1);

		System.out.println("enter the customer name ");
		String name3 = sc.next();
		c3.setCname(name3);
		System.out.println("enter the customer address ");
		String add3 = sc.next();
		c3.setAddress(add3);
		System.out.println("enter the customer phone number ");
		long phno3 = sc.nextLong();
		c3.setPhno(phno3);

		Product p1 = new Product();
		Product p2 = new Product();
		Product p3 = new Product();

		System.out.println("enter the product name ");
		String namee = sc.next();
		p1.setPname(namee);
		System.out.println("enter the product address ");
		String addr = sc.next();
		p1.setAddress(addr);
		System.out.println("enter the product price ");
		double price = sc.nextDouble();
		p1.setPrice(price);

		System.out.println("enter the product name ");
		String nam = sc.next();
		p2.setPname(nam);
		System.out.println("enter the product address ");
		String ad = sc.next();
		p2.setAddress(ad);
		System.out.println("enter the product price ");
		double price1 = sc.nextDouble();
		p2.setPrice(price1);

		System.out.println("enter the product name ");
		String name2 = sc.next();
		p3.setPname(name2);
		System.out.println("enter the product address ");
		String add2 = sc.next();
		p3.setAddress(add2);
		System.out.println("enter the product price ");
		double price3 = sc.nextDouble();
		p1.setPrice(price3);

		List<Product> l = new ArrayList<Product>();
		l.add(p2);
		l.add(p3);

		List<Product> l1 = new ArrayList<Product>();
		l1.add(p3);
		l1.add(p1);

		List<Product> l2 = new ArrayList<Product>();
		l2.add(p2);
		l2.add(p1);

		List<CustomerDto> c = new ArrayList<CustomerDto>();
		c.add(c2);
		c.add(c3);

		c1.setProducts(l1);
		p1.setCustomerDtos(c);

		List<CustomerDto> cu = new ArrayList<CustomerDto>();
		cu.add(c3);
		cu.add(c1);

		c2.setProducts(l);
		p2.setCustomerDtos(cu);

		List<CustomerDto> cus = new ArrayList<CustomerDto>();
		cus.add(c1);
		cus.add(c2);

		c3.setProducts(l2);
		p3.setCustomerDtos(cus);

//		 MainClass ma=new MainClass();
//		ma.fetch(2);

		et.begin();
		em.persist(c1);
		em.persist(c2);
		em.persist(c3);
		em.persist(p1);
		em.persist(p2);
		em.persist(p3);
		et.commit();

	}
}
