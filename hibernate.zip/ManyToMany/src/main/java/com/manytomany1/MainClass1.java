package com.manytomany1;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass1 {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("magician");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Product p1=new Product();
		Product p2=new Product();
		Product p3=new Product();
		
		Customer c1=new Customer();
		Customer c2=new Customer();
		Customer c3=new Customer();
		
		c1.setCid(11);
		c1.setCname("ram");
		c2.setCid(22);
		c2.setCname("sumana");
		c3.setCid(33);
		c3.setCname("kish");
		
		
		p1.setPid(41);
		p1.setPname("Apple");
		
		p2.setPid(42);
		p2.setPname("mobile");
		
		p3.setPid(43);
		p3.setPname("Mac");
		
        List<Product> l1=new ArrayList();
         l1.add(p1);
         l1.add(p3);
         
         
         List<Customer> l2=new ArrayList();
         l2.add(c1);
         l2.add(c2);
         
         
         c1.setP(l1);
         p1.setC(l2);
         
         
         List<Product> l3=new ArrayList();
         l1.add(p2);
         l1.add(p3);
         
         
         List<Customer> l4=new ArrayList();
         l2.add(c1);
         l2.add(c3);
         
         c2.setP(l3);
         p2.setC(l4);
       
         et.begin();
           em.persist(c1);
           for (Customer customer :p1.getC())
           {
			 em.persist(customer);
		   }
           em.persist(p1);
           for (Product product :c1.getP()) 
           {
			em.persist(product);
		   }
           em.persist(c2);
           for (Customer customer :p2.getC())
           {
			 em.persist(customer);
		   }
           em.persist(p2);
           for (Product product :c2.getP()) 
           {
			em.persist(product);
		   }
         et.commit();
	}

}
