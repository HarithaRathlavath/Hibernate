package Dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Faculties {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int facid;
	private String facname;
	private String subject;
	private String ecperience;
	@ManyToOne
	private Institute ins;

	public int getFacid() {
		return facid;
	}

	public void setFacid(int facid) {
		this.facid = facid;
	}

	public String getFacname() {
		return facname;
	}

	public void setFacname(String facname) {
		this.facname = facname;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEcperience() {
		return ecperience;
	}

	public void setEcperience(String ecperience) {
		this.ecperience = ecperience;
	}

	public Institute getIns() {
		return ins;
	}

	public void setIns(Institute ins) {
		this.ins = ins;
	}

	@Override
	public String toString() {
		return "Faculties [facid=" + facid + ", facname=" + facname + ", subject=" + subject + ", ecperience="
				+ ecperience + ", ins=" + ins + "]";
	}

}
