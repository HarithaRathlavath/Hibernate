package Dto;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Institute 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String insname;
	private long phno;
	private String address;
    @OneToMany
    private List<Faculties> fac;
	
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getInsname() {
		return insname;
	}

	public void setInsname(String insname) {
		this.insname = insname;
	}

	public long getPhno() {
		return phno;
	}

	public void setPhno(long phno) {
		this.phno = phno;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public List<Faculties> getFac() {
		return fac;
	}

	public void setFac(List<Faculties> fac) {
		this.fac = fac;
	}

	@Override
	public String toString() {
		return "Institute [id=" + id + ", insname=" + insname + ", phno=" + phno + ", address=" + address + ", fac="
				+ fac + "]";
	}

//	@Override
//	public String toString()
//	{
//		return "institute +insname+";
//	}
}
