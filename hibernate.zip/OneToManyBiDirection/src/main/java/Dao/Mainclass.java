package Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import Dto.Faculties;
import Dto.Institute;

public class Mainclass {
   EntityManagerFactory emf=Persistence.createEntityManagerFactory("onetomany");
   EntityManager entityManager=emf.createEntityManager();
   EntityTransaction entityTransaction=entityManager.getTransaction();
   
  public void insertDetails(Institute institute)
  {
	  List<Faculties> f=institute.getFac();
	  entityTransaction.begin();
	  for (Faculties faculties : f) 
		  entityManager.persist(faculties);
	      entityManager.persist(institute);
	      entityTransaction.commit();
	  
  }
  
  
  
}
