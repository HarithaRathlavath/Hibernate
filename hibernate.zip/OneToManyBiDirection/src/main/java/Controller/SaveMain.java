package Controller;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import Dao.Mainclass;
import Dto.Faculties;
import Dto.Institute;

public class SaveMain 
{
	public static void main(String[] args) {
		Institute in=new Institute();
		in.setInsname("jspider");
		in.setPhno(970404765l);
		in.setAddress("dilsukhnagar");
	
		
		
		Faculties f=new Faculties();
		f.setFacname("AA");
		f.setSubject("java");
		f.setEcperience("3years");
		f.setIns(in);
		
		Faculties f1=new Faculties();
		f.setFacname("BB");
		f.setSubject("Advance");
		f.setEcperience("4years");
		f.setIns(in);
		
		Faculties f2=new Faculties();
		f.setFacname("CC");
		f.setSubject("Web tech");
		f.setEcperience("3years");
		f.setIns(in);
		
		List<Faculties> l=new ArrayList<Faculties>();
		l.add(f);
		l.add(f1);
		l.add(f2);
		
		in.setFac(l);
		
		Mainclass s=new Mainclass();
		s.insertDetails(in);

	}

}
