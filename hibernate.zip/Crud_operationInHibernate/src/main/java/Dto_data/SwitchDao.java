package Dto_data;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import java.util.*;

public class SwitchDao {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("magician");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		school v = new school();
		college m = new college();
		System.out.println("Enter here 1.insert \t 2.update \t 3.delete \t 4.fetch  ");
		int key = sc.nextInt();
		switch (key) {
		case 1:
			System.out.println("Enter id");
			int a1 = sc.nextInt();
			v.setId(a1);
			System.out.println("Enete sname");
			String a2 = sc.next();
			v.setSname(a2);
			System.out.println("Enter age");
			int a3 = sc.nextInt();
			v.setAge(a3);
			System.out.println("Enter School name ");
			String a4 = sc.next();
			v.setScname(a4);

			System.out.println("Enter id");
			int s1 = sc.nextInt();
			m.setId(s1);
			System.out.println("Enete name");
			String s2 = sc.next();
			m.setName(s2);
			System.out.println("Enter age");
			int s3 = sc.nextInt();
			m.setAge(s3);
			System.out.println("Enter college name ");
			String s4 = sc.next();
			m.setColname(s4);
			System.out.println("Enter sid");
			int s5 = sc.nextInt();
			m.setId(s5);

			et.begin();
			em.persist(v);
			em.persist(m);
			et.commit();

			break;

		case 2:
			System.out.println("update here...");
			System.out.println(" 1.sid \n 2.sname \n 3.sage \n 4.scname \n 5.cid ");
			int n = sc.nextInt();
			switch (n) {
			case 1:
				System.out.println("update sname");

				et.begin();
				String s = "";
				System.out.println(" enter the id ");
				int sv = sc.nextInt();
				Query q = em.createQuery("update school set sname='" + s + "' where id='" + sv + "' ");
				q.executeUpdate();
				et.commit();

				break;
			case 2:
				System.out.println("update  here.. \n enter the age");
				int nn = sc.nextInt();
				et.begin();
				System.out.println(" enter the id ");
				int sv1 = sc.nextInt();
				Query q1 = em.createQuery("update school set age='" + nn + "'  where id='" + sv1 + "' ");
				q1.executeUpdate();
				et.commit();

				break;

			default:

			}

		case 3:

			System.out.println(" choose which one u want to delete here ");
			System.out.println(" 1.id \n 2.sname \n 3.age");
			int n1=sc.nextInt();
			
			switch (n1) {
			case 1:
				System.out.println(" Enter the id  ");
				et.begin();
				int ss=sc.nextInt();
				Query q=em.createQuery("delete from  school where id='"+ss+"' ");
				Query q1=em.createQuery("delete from college where id='"+ss+"' ");
				q.executeUpdate();
				q1.executeUpdate();
				et.commit();
				
				break;
			case 2:
				System.out.println("Enter the sname  ");
				
				et.begin();
				String s="";
				Query q2=em.createQuery("delete from school  where sname='"+s+"'");
				Query q3=em.createQuery("delete from name where id='"+s+"' ");
				q2.executeUpdate();
				q3.executeUpdate();
				
				et.commit();
				
			   break;
			case 3:
				System.out.println(" Enter the age ..  ");
	            et.begin();
	            String s6="";
			    Query qq=em.createQuery("delete from  school where age='"+s6+"'");
			    qq.executeUpdate();
			    et.commit();
			break;
			default:
				System.out.println("please choose correct one ........ ");
				break;
			}	
			
		
		case 4:
			  
		
		}

	}
}
