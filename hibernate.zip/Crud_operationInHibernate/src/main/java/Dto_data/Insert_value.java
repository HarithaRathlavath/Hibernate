package Dto_data;

import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Insert_value {

static Scanner sc = new Scanner(System.in);

 public void std(school v, college m) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("magician");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

//	school v=new school();
//	college m=new college();

		int id = v.getId();
		String sname = v.getSname();
		int age = v.getAge();
		String scname = v.getScname();

		int id1 = m.getId();
		String name = m.getName();
		int age1 = m.getAge();
		String colname = m.getColname();

		v.setId(id);
		v.setSname(sname);
		v.setAge(age);
		v.setScname(scname);
		
		m.setId(id1);
		m.setName(name);
		m.setAge(age1);
		m.setColname(colname);
		
		et.begin();
		em.persist(v);
		em.persist(m);
		et.commit();

	}

}