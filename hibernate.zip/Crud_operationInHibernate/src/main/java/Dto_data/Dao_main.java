package Dto_data;

import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.*;

public class Dao_main {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		school v= new school();
		college m= new college();

		Insert_value j= new Insert_value();
		j.std(v, m);

		System.out.println("Enter here school information...");
		System.out.println("Enter id");
		int a1 = sc.nextInt();
		v.setId(a1);
		System.out.println("Enete sname");
		String a2 = sc.next();
		v.setSname(a2);
		System.out.println("Enter age");
		int a3 = sc.nextInt();
		v.setAge(a3);
		System.out.println("Enter School name ");
		String a4 = sc.next();
		v.setScname(a4);

		System.out.println("Enter here college information...");
		System.out.println("Enter id");
		int s1 = sc.nextInt();
		m.setId(s1);
		System.out.println("Enete name");
		String s2 = sc.next();
		m.setName(s2);
		System.out.println("Enter age");
		int s3 = sc.nextInt();
		m.setAge(s3);
		System.out.println("Enter college name ");
		String s4 = sc.next();
		m.setColname(s4);
		System.out.println("Enter sid");
		int s5 = sc.nextInt();
		m.setId(s5);

//		EntityManagerFactory emf=Persistence.createEntityManagerFactory("magician");
//		EntityManager em=emf.createEntityManager();
//		EntityTransaction et=em.getTransaction();
//		
//		school v=new school();
//		college m=new college();
//		System.out.println("Enter here 1.insert \t 2.update \t 3.delete \t 4.fetch  ");
//		int key=sc.nextInt();
//		switch (key) {
//		case 1: 
//			    System.out.println("Enter id");
//		        int a1=sc.nextInt();
//		        v.setId(a1);
//		        System.out.println("Enete sname");
//		        String a2=sc.next();
//		        v.setSname(a2);
//		        System.out.println("Enter age");
//		        int a3=sc.nextInt();
//		        v.setAge(a3);
//		        System.out.println("Enter School name ");
//		        String a4=sc.next();
//		         v.setScname(a4);
//		         
//		         
//		            System.out.println("Enter id");
//			        int s1=sc.nextInt();
//			        m.setId(s1);
//			        System.out.println("Enete name");
//			        String s2=sc.next();
//			        m.setName(s2);
//			        System.out.println("Enter age");
//			        int s3=sc.nextInt();
//			        m.setAge(s3);
//			        System.out.println("Enter college name ");
//			        String s4=sc.next();
//			        m.setColname(s4);
//			        System.out.println("Enter sid");
//			        int s5=sc.nextInt();
//			        m.setId(s5);
//			        
//		         et.begin();
//		         em.persist(v);
//		         em.persist(m);
//		         et.commit();
//			
//			break;
//
//		default:
//			break;
//		}
//	
		
}

}
