package com.OneToOne;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Person1 {
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private String jobRole;
	private double salary;
	@OneToOne
	private Adhar a;

	public Adhar getA()
	{
		return a;
	}

	public void setA(Adhar a) 
	{
		this.a = a;
	}

	public int getId() 
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	public String getJobRole() 
	{
		return jobRole;
	}

	public void setJobRole(String jobRole)
	{
		this.jobRole = jobRole;
	}

	public double getSalary()
	{
		return salary;
	}

	public void setSalary(double salary)
	{
		this.salary = salary;
	}

	
}