package com.OneToOne;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Read {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("magician");
	EntityManager em=emf.createEntityManager();
	EntityTransaction et=em.getTransaction();
	public List<Person1> getAll()
	{
		Query q=em.createQuery("select a from Person1 a");
		List<Person1> l=q.getResultList();
		return l;
	}
	public Person1 find(int i)
	{
		return em.find(Person1.class, i);
	}
	public Adhar findAdhar(long l)
	{
		return em.find(Adhar.class, l);
	}
}