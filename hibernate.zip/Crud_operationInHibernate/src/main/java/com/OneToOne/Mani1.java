package com.OneToOne;

	import java.util.List;

	import java.util.Scanner;
	import org.hibernate.annotations.Check;
	


	public class Mani1 {
		static Scanner sc=new Scanner(System.in);
		static Person1 p=new Person1();
		static Adhar a=new Adhar();
	    static PersonService personService=new PersonService();
	public static void main(String[] args) {
		
		System.out.println("Enter 1 to Insert datails");
		System.out.println("Enter 2 to Delete");
		System.out.println("Enter 3 to update your details");
		System.out.println("Enter 4 to read your details");
		int option=sc.nextInt();
		switch(option)
		{
		case 1:
		{
			System.out.println("Enter  id");
			p.setId(sc.nextInt());
			System.out.println("Enter Name");
			p.setName(sc.next());
			System.out.println("Enter jobRole");
			p.setJobRole(sc.next());
			System.out.println("Enter salary");
			p.setSalary(sc.nextInt());
			System.out.println("Enter Adhar card");
			a.setAdharNumber(sc.nextLong());
			System.out.println("enter name for adhar");
			a.setName(sc.next());
			System.out.println("Enter phne");
			a.setPhne(sc.nextDouble());
			p.setA(a);
			a.setP(p);
			if(check(p.getId())==false)
			{
			personService.insert(p);
			}
			else
			{
				System.out.println("id already exists");
			}
			break;
			
		}
		case 2:
		{
			System.out.println("Enter your id or AdharNumber");
			long k=sc.nextLong();
			
			if(check(k))
			{
				int k1=(int)k;
				personService.delete(k1);
			}
			else if(checkAdhar(k))
			{
				personService.deleteAdhar(k);
		
			}
			else
			{
				System.out.println("id not found");
			}
			break;
		}
		case 3:
		{
			System.out.println("Enter your id or Adhar number");
			long id=sc.nextLong();
			if(check(id)||checkAdhar(id))
			
			{
				//Person1 p=personService.find(id);
				Person1 p;
				
				if(check(id))
				{
					int id1=(int)id;
					p=personService.find(id1);
				}
				else
				{
					p=personService.findAdhar(id).getP();
				}
			boolean b=true;
			while(b)
		{
			System.out.println("enter 1 to update the Name");
			System.out.println("enter 2 to update Phne");
			System.out.println("enter 3 to update name in adharCard");
			System.out.println("enter 4 to Submit or Skip");
			int k=sc.nextInt();
			switch(k)
			{
			case 1:
			{
				System.out.println("Enter the Name to Update");
			p.setName(sc.next());
				break;
			}
			case 2:
			{
				System.out.println("Enter your phne");
				p.getA().setPhne(sc.nextLong());
				break;
			}
			case 3:
			{
				System.out.println("enter your name to Update on Adhar card");
				p.getA().setName(sc.next());
				break;
			}
			case 4:
			{
				b=false;
				personService.update(p);
				break;
			}
			
			}
		}
			}
			else
			{
				System.out.println(" id  not found unable to update");
			}
			break;
		}
		case 4:
		{
			System.out.println("Enter your id or AdharNumber");
			long k=sc.nextLong();
			if(check(k))
			{
				int k1=(int)k;
				Person1 p=personService.find(k1);
				System.out.println("Name :"+p.getName());
				System.out.println("jobRole :"+p.getJobRole());
				System.out.println("Salary :"+p.getSalary());
				System.out.println("AdharNumber :"+p.getA().getAdharNumber());
				System.out.println("phone :"+p.getA().getPhne());
				
				
			}
			else if(checkAdhar(k))
			{
				Adhar a=personService.findAdhar(k);
				System.out.println("Name :"+a.getP().getName());
				System.out.println("jobrole :"+a.getP().getJobRole());
				System.out.println("salary :"+a.getP().getSalary());
				System.out.println("adharnumber :"+a.getAdharNumber());
				System.out.println("phone"+a.getPhne());
			}
			break;
		}
		default:
			System.out.println("invalid input");
		
		
	}
	}
	public static boolean check(long k)
	{
		
		boolean b=false;
		List<Person1> list=personService.getAll();
		for(Person1 p1:list)
		{
			if(p1.getId()==k)
			{
				b=true;
				break;
			}
			
		}
		return b;
		}
	public static boolean checkAdhar(long  k)
	{
		
		boolean b=false;
		List<Person1> list=personService.getAll();
		for(Person1 p1:list)
		{
			if(p1.getA().getAdharNumber()==k)
		{
			b=true;
				break;
				
			}
			
		}
		return b;
		}

	}
	
