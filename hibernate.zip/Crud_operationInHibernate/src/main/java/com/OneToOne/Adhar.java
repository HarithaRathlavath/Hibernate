package com.OneToOne;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Adhar 
{
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long adharNumber;
	private String name;
	private double phne;
	@OneToOne
	private Person1 p;

	
	public long getAdharNumber()
	{
		return adharNumber;
	}

	public void setAdharNumber(long adharNumber)
	{
		this.adharNumber=adharNumber;
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	public double getPhne() 
	{
		return phne;
	}

	public void setPhne(double phne)
	{
		this.phne = phne;
	}

	public Person1 getP()
	{
		return p;
	}

	public void setP(Person1 p)
	{
		this.p = p;
	}

}