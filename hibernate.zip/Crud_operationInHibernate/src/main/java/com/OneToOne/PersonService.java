package com.OneToOne;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class PersonService {

	public void insert(Person1 p1) 
	{
		InserDetails inserDetails = new InserDetails();
		inserDetails.insert(p1);
	}

	public List<Person1> getAll() 
	{
		Read r=new Read();
		return r.getAll();
	}

	public void delete(int k) 
	{
		Delete d = new Delete();
		d.delete(k);
	}

	public void deleteAdhar(long k)
	{
		Delete d = new Delete();
		d.deleteAdhar(k);
	}

	public void update(Person1 p) 
	{
		Update u = new Update();
		u.update(p);
	}

	public Person1 find(int k) 
	{
		Read r = new Read();
		return r.find(k);
	}

	public Adhar findAdhar(long k)
	{
		Read r=new Read();
		return r.findAdhar(k);
	}

}