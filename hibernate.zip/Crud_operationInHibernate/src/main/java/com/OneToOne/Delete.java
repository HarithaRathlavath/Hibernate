package com.OneToOne;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


public class Delete 
{
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("magician");
	EntityManager em = emf.createEntityManager();
	EntityTransaction et = em.getTransaction();

	public void delete(int k) 
	{

		Person1 p = em.find(Person1.class, k);
		et.begin();
		// Person1 p=em.find(Person1,k);
		em.remove(p);
		em.remove(p.getA());
		et.commit();
	}

	public void deleteAdhar(long k) 
	{

		Adhar p = em.find(Adhar.class, k);
		et.begin();			
       //Person1 p=em.find(Person1,k);

		em.remove(p.getP());
		em.remove(p);
		et.commit();
	}
}
