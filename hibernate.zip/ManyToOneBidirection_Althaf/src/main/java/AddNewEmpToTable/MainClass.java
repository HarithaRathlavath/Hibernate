package AddNewEmpToTable;

import java.util.ArrayList;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.bidirection.Emp1;

public class MainClass 
{

	public static void main(String[] args) 
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("magician");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Dto_Dept d=new Dto_Dept();
		Dto_Dept d1=new Dto_Dept();
		Dto_Dept d2=new Dto_Dept();
		
		Dto_Emp e=new Dto_Emp();
		Dto_Emp e1=new Dto_Emp();
		Dto_Emp e2=new Dto_Emp();
		
		e1.setEid(1);
		e1.setEname("hari");
		e1.setEmobile(7672028753l);
		e1.setEage(20);
		e1.setEdept_no(3);
		e1.setEsal(1000000);
		e1.setD(d1);
		
		e2.setEid(2);
		e2.setEname("sumana");
		e2.setEmobile(8972028753l);
		e2.setEage(22);
		e2.setEdept_no(1);
		e2.setEsal(500000);
		e2.setD(d2);
		
		e.setEid(5);
		e.setEname("priyanka");
		e.setEmobile(9972028753l);
		e.setEage(23);
		e.setEdept_no(2);
		e.setEsal(1500000);
		e.setD(d);
		
		d.setDdept_no(1);
		d.setDname("developer");
		d.setDloc("hyderabad");
		
		d1.setDdept_no(2);
		d1.setDname("Testing");
		d1.setDloc("madhapur");
		
		d2.setDdept_no(5);
		d2.setDname("designing");
		d2.setDloc("hitec");
		
		
		 List<Dto_Emp> l1=new ArrayList<Dto_Emp>();
        
         l1.add(e2);
         
         List<Dto_Emp> l2=new ArrayList<Dto_Emp>();
         l2.add(e);
        
         
         List<Dto_Emp> l3=new ArrayList<Dto_Emp>();
         l3.add(e1);
        
         
         d.setE(l2);
         d1.setE(l3);
         d2.setE(l1);
         
      et.begin();
      
      em.persist(e);
      em.persist(e1);
      em.persist(e2);
      em.persist(d);
      em.persist(d1);
      em.persist(d2);
//      em.persist(l1);
//      em.persist(l2);
//      em.persist(l3);
//      em.persist(e);
//      
         
      et.commit();
         

	  }
}









