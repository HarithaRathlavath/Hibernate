package AddNewEmpToTable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
@Entity
public class Dto_Emp {
	@Id
	private int eid;
	private String ename;
	private long emobile;
	private int eage;
	private double esal;
	private int edept_no;
	@ManyToOne
	private Dto_Dept d;
	
	public int getEdept_no() {
		return edept_no;
	}

	public void setEdept_no(int edept_no) {
		this.edept_no = edept_no;
	}

	

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public long getEmobile() {
		return emobile;
	}

	public void setEmobile(long emobile) {
		this.emobile = emobile;
	}

	public int getEage() {
		return eage;
	}

	public void setEage(int eage) {
		this.eage = eage;
	}

	public double getEsal() {
		return esal;
	}

	public void setEsal(double esal) {
		this.esal = esal;
	}

	public Dto_Dept getD() {
		return d;
	}

	public void setD(Dto_Dept d) {
		this.d = d;
	}

}
