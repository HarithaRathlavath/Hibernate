package AddNewEmpToTable;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Dao_fetch {
         public static Dto_Dept fetching(int id)
         {
        	 EntityManagerFactory emf=Persistence.createEntityManagerFactory("magician");
        	 EntityManager em=emf.createEntityManager();
        	 EntityTransaction et=em.getTransaction();
        	 Dto_Dept a=em.find(Dto_Dept.class, id);
        	 
        	 return a;
         }
}
