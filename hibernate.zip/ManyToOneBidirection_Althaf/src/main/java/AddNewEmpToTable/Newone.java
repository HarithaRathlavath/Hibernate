package AddNewEmpToTable;
import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
public class Newone {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("magician");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		
		
		System.out.println("ENTER THE DEPT ID TO ENTER THE EMPLOYEE DETAILS");
		int id=sc.nextInt();
		Dto_Dept d1=Dao_fetch.fetching(id);
		Dto_Emp e1=new Dto_Emp();
		//e1.setEid(id);
		System.out.println("ENTER THE EID");
		int q=sc.nextInt();
		//e1.setEid(id);
		e1.setEid(q);
		System.out.println("ENTER THE ENAME");
		String s=sc.next();
		e1.setEname(s);
		System.out.println("ENTER THE AGE");
		int w=sc.nextInt();
		e1.setEage(w);
		System.out.println("ENTER THE MOBILE ");
		long l=sc.nextLong();
		e1.setEmobile(l);
		System.out.println("ENTER THE DDEPT");
		int z=sc.nextInt();
		e1.setEdept_no(z);
		e1.setD(d1);
		
		Dto_Dept d=new Dto_Dept();
		//d1.getE().add(e1);
		d.setE(d1);
		
		et.begin();
		
		em.persist(e1);
		em.merge(d1);
		
		et.commit();
		
		
		
	}

}
