package AddNewEmpToTable;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Dto_Dept {
	@Id
    private int ddept_no;
    private String dname;
    private String dloc;
    @OneToMany
    private List<Dto_Emp> e;
	
	public List<Dto_Emp> getE() {
		return e;
	}
	public void setE(List<Dto_Emp> e) {
		this.e = e;
	}
	public int getDdept_no() {
		return ddept_no;
	}
	public void setDdept_no(int ddept_no) {
		this.ddept_no = ddept_no;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getDloc() {
		return dloc;
	}
	public void setDloc(String dloc) {
		this.dloc = dloc;
	}
    
}
