package com.userData;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import java.util.List;
@Entity
public class Deptment2 {
	@Id
	private int dept_no;
	private String loc;
	private String dname;
	@OneToMany
	private List<Dto_Employee2> l2;
	public int getDept_no() {
		return dept_no;
	}
	public void setDept_no(int dept_no) {
		this.dept_no = dept_no;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public List<Dto_Employee2> getL2() {
		return l2;
	}
	public void setL2(List<Dto_Employee2> v) {
		this.l2=v;
		
	}
	
	
}
