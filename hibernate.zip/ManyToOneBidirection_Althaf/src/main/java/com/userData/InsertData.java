package com.userData;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class InsertData {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("magician");
	EntityManager em=emf.createEntityManager();
	EntityTransaction et=em.getTransaction();
    public void insert(Dto_Employee2 l) {
    	 et.begin();
    	 em.persist(l);
    	 em.persist(l.getD());
    	 et.commit();
    }
}
