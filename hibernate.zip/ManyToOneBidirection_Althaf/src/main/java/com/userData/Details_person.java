package com.userData;

public class Details_person {
    
	
	public void insert(Dto_Employee2 l)
	{
		
	}
}
