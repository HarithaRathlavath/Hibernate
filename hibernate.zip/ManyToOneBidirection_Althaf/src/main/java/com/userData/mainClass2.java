package com.userData;
import java.util.*;
public class mainClass2 {
	static Scanner sc=new Scanner(System.in);
    static Dto_Employee2 v=new Dto_Employee2();
    static Deptment2 e=new Deptment2();
    static Details_person k=new Details_person();
    
	public static void main(String[] args) {
		System.out.println("Enter 1 to Insert datails");
		System.out.println("Enter 2 to Delete");
		System.out.println("Enter 3 to update your details");
		System.out.println("Enter 4 to read your details");
		int option=sc.nextInt();
		switch (option) {
		case 1:
			System.out.println("Enter the emp_no");
			v.setEmp_no(sc.nextInt());
			System.out.println("Enter the ename");
			v.setName(sc.next());
			System.out.println("Enter the job");
			v.setJob(sc.next());
			System.out.println("Enter the salary");
			v.setSal(sc.nextDouble());
			System.out.println("Enter the dept_no");
			e.setDept_no(sc.nextInt());
			System.out.println("Enter the loc");
			e.setLoc(sc.next());
			System.out.println("Enter the dname");
			e.setDname(sc.next());
			v.setD(e);
			//e.setL2(v);
			
			

			break;

		default:
			break;
		}
		System.out.println(" ");

	}

}
