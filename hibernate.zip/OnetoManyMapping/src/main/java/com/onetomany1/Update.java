package com.onetomany1;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Update {
    public static void main(String[] args) {
    	EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("magician");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		 
		entityTransaction.begin();
		Query q=entityManager.createQuery("update Emp set sal='5000' where name='blake' ");
		Query q1=entityManager.createNamedQuery("update Dept1 set dname='accounting' where dept_no='1'");
		q.executeUpdate();
		entityTransaction.commit();
		
	}
}
