package com.onetomany1;

import java.util.ArrayList;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.mapping.Array;

public class MainClass1 {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("magician");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		Emp e1=new Emp();
		Emp e2=new Emp();
		Emp e3=new Emp();
		Emp e4=new Emp();
		
		e1.setEmp_no(1);
		e1.setName("scott");
		e1.setJob("manager");
		e1.setSal(10000);
		e1.setdept_no(1);
		
		
		e2.setEmp_no(2);
		e2.setName("mark");
		e2.setJob("salesman");
		e2.setSal(9000);
		e2.setdept_no(2);
		
		
		e3.setEmp_no(3);
		e3.setName("king");
		e3.setJob("president");
		e3.setSal(50000);
		e3.setdept_no(2);
		
		e4.setEmp_no(4);
		e4.setName("blake");
		e4.setJob("clerk");
		e4.setSal(3000);
		e4.setdept_no(1);
		
         Dept1 d1=new Dept1();
         Dept1 d2=new Dept1();
         
         d1.setDept_no(1);
         d1.setLoc("newyork");
         d1.setDname("accounting");
        
         d2.setDept_no(2);
         d2.setLoc("mumbai");
         d2.setDname("salesman");
        
         List<Emp> li1=new ArrayList<Emp>();
         li1.add(e1);
         li1.add(e4);
         
         List<Emp> li2=new ArrayList<Emp>();
         li2.add(e2);
         li2.add(e3);
         
         d1.setL1(li1);
         d2.setL1(li2);
         
         et.begin();
//         em.persist(d1);
//         for (Emp emp :d1.getL1()){
         
//			em.persist(emp);
//		 }
         em.persist(d2);
         for (Emp emp : d2.getL1())
         {
			em.persist(emp);
		 }
         
         et.commit();
         
	}

}
