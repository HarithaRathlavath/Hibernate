package com.onetomany1;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Delete {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("magician");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		 
		Emp f=entityManager.find(Emp.class, 4);
		entityTransaction.begin();
		Query q=entityManager.createQuery("delete from Emp where name='blake' ");
		q.executeUpdate();
		
		entityTransaction.commit();

	}

}
