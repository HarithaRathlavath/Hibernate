package com.onetomany1;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Dept1 {
	
	@Id
	private int dept_no;
	private String loc;
	private String dname;
	@OneToMany
	private List<Emp> l1;

	public int getDept_no() {
		return dept_no;
	}

	public void setDept_no(int dept_no) {
		this.dept_no = dept_no;
	}

	public String getLoc() {
		return loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public List<Emp> getL1() {
		return l1;
	}

	public void setL1(List<Emp> l1) {
		this.l1 = l1;
	}

}
