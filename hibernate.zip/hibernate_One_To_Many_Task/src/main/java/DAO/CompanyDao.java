package DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import DTO.Company;
import DTO.Employee;

public class CompanyDao {
 EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("vivek");
 EntityManager entityManager=entityManagerFactory.createEntityManager();
 EntityTransaction entityTransaction=entityManager.getTransaction();
 
 
 public void insert(Company company) {
	 List<Employee> list=company.getEmployee();
	 entityTransaction.begin();
	 for(Employee employee:list) {
		 entityManager.persist(employee); 
	 }
	 entityManager.persist(company);
	 entityTransaction.commit();
 }
 public void fetchAll() {
	 
 }
 
 
}
