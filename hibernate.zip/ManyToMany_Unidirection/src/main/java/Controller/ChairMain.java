package Controller;

import java.util.ArrayList;
import java.util.List;

import Dao.ChairDao;
import Dto.Chairs;
import Dto.Student;

public class ChairMain {

	public static void main(String[] args) {
      
		
		Chairs c=new Chairs();
		c.setBrand("VBN");
		c.setAdd("hyd");
		
		Chairs c1=new Chairs();
		c1.setBrand("Jk");
		c1.setAdd("kmr");
		
		Student s=new Student();
		s.setName("sravya");
		s.setAge(23);
		s.setAttendence("90");
		
		Student s1=new Student();
		s1.setName("priya");
		s1.setAge(23);
		s1.setAttendence("70");
		
		Student s2=new Student();
		s2.setName("hari");
		s2.setAge(21);
		s2.setAttendence("90");
		
		List<Student>std=new ArrayList<Student>();
		std.add(s2);
		std.add(s1);
		std.add(s);
		
		c.setStudent(std);
		c1.setStudent(std);
		
		ChairDao v=new ChairDao();
		v.insert(c);
		v.insert(c1);
	}

}
