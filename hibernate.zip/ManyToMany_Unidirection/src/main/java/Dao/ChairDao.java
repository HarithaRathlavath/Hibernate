package Dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import Dto.Chairs;

public class ChairDao {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("haritha");
	EntityManager em = emf.createEntityManager();
	EntityTransaction et = em.getTransaction();

	public void insert(Chairs chairs) {
		et.begin();
		em.persist(chairs);
		et.commit();
	}
}
